package Commons;

public interface Address {
    String dest();
    int port();
}
